import React from "react";

function Cart() {
  return (
    <div className="container">
      <h1 id="products_heading">Cart Page</h1>
      <hr />
      <table border="1px">
        <tr>
          <th>Image</th>
          <th>Name</th>
          <th> Price</th>
        </tr>
        <tr>
          <td>gaJSDjhg</td>
          <td>jhdsi.yhkha</td>
          <td>56356</td>
        </tr>
        <tr>
          <td>gaJSDjhg</td>
          <td>jhdsi.yhkha</td>
          <td>56356</td>
        </tr>
        <tr>
          <td>gaJSDjhg</td>
          <td>jhdsi.yhkha</td>
          <td>56356</td>
        </tr>
      </table>
    </div>
  );
}

export default Cart;
