//All Required Dependancies

import React, { useState } from "react";
import "../assets/css/login.css";
import { MDBContainer, MDBRow, MDBCol } from "mdb-react-ui-kit";
import { Button } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import InputTextComponent from "../component/InputTextComponent";
import LableComponent from "../component/LableComponent";
import { FaRegEye, FaEyeSlash } from "react-icons/fa";

function Register() {
  const navigate = useNavigate();

  // Require State for the all InputTextComponent
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [number, setNumber] = useState("");
  const [password, setPassword] = useState("");
  const [cpassword, setCpassword] = useState("");
  const [error, setError] = useState(false);
  const [regemail, setRegemail] = useState(false);
  const [allError, setAllError] = useState(false);
  const [passwordError, setPasswordError] = useState(false);

  const [passwordIcon, setPasswordIcon] = useState(<FaEyeSlash />);
  const [passwordType, setPasswordType] = useState("password");
  const [cPassworIcon, setCPasswordIcon] = useState(<FaEyeSlash />);
  const [cPasswordType, setCPasswordType] = useState("password");

  //password hide & show Toggle Function
  const passwordToggle = () => {
    if (passwordType === "password") {
      setPasswordType("text");
      setPasswordIcon(FaRegEye);
    } else {
      setPasswordType("password");
      setPasswordIcon(FaEyeSlash);
    }
  };
  const confirmToggle = () => {
    if (cPasswordType === "password") {
      setCPasswordType("text");
      setCPasswordIcon(FaRegEye);
    } else {
      setCPasswordType("password");
      setCPasswordIcon(FaEyeSlash);
    }
  };

  // validation condition for all TextInputComponent

  let regmail = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w\w+)+$/;

  const validation = () => {
    if (
      name.length === 0 ||
      email.length === 0 ||
      number.length === 0 ||
      password.length === 0 ||
      cpassword.length === 0
    ) {
      setAllError(true);
    } else if (regmail.test(email) === false) {
      setRegemail(true);
    } else if (password !== cpassword) {
      setPasswordError(true);
    } else {
      navigate("/login");
    }
  };

  return (
    <MDBContainer className="my-3 gradient-form">
      <MDBRow>
        <MDBCol col="4" className="mb-5">
          <div className="d-flex flex-column ms-5">
            <div className="text-center">
              <img
                src="assets/logo/mai.png"
                style={{ width: "100px" }}
                alt="logo"
              />
              <h6 id="title">REGISTRATION PAGE</h6>
            </div>
            <br />
            <p id="para">Please fill your details</p>

            <InputTextComponent
              placeholder="Enter Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              type="text"
            />

            {allError && name.length <= 0 ? (
              <LableComponent text="name can't be empty" />
            ) : (
              ""
            )}

            <InputTextComponent
              placeholder="Email address"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                setRegemail(false);
                setError(false);
              }}
              type="email"
            />

            {allError && email.length <= 0 ? (
              <LableComponent text="Email can't be empty" />
            ) : (
              ""
            )}
            {regemail || (error && email.length <= 0) ? (
              <LableComponent text="Please Enter Valid Email" />
            ) : (
              ""
            )}

            <InputTextComponent
              placeholder="Enter Mobile"
              value={number}
              onChange={(e) => setNumber(e.target.value)}
              type="number"
            />

            {allError && number.length <= 0 ? (
              <LableComponent text="Mobile No can't be empty" />
            ) : (
              ""
            )}
            <InputTextComponent
              placeholder="Password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setPasswordError(false);
              }}
              type={passwordType}
            />
            <p id="passeye" onClick={passwordToggle}>
              {passwordIcon}
            </p>
            {allError && password.length <= 0 ? (
              <LableComponent text="Password can't be empty" />
            ) : (
              ""
            )}
            <InputTextComponent
              placeholder=" Confirm Password"
              value={cpassword}
              onChange={(e) => {
                setCpassword(e.target.value);
                setPasswordError(false);
              }}
              type={cPasswordType}
            />

            <p id="passeye" onClick={confirmToggle}>
              {cPassworIcon}
            </p>

            {allError && cpassword.length <= 0 ? (
              <LableComponent text="Confirm Pass can't be empty" />
            ) : (
              ""
            )}
            {passwordError ? (
              <LableComponent text="password & confirm password must be same" />
            ) : (
              ""
            )}

            <Button id="signin" onClick={validation}>
              Register Now
            </Button>
            <br />

            <p id="regto">
              <Link to="/login">Already have an account</Link>
            </p>
          </div>
        </MDBCol>
      </MDBRow>
    </MDBContainer>
  );
}
export default Register;
