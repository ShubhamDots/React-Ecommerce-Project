//All Required Dependancies

import { FaRegEye, FaEyeSlash } from "react-icons/fa";
import "../assets/css/login.css";
import { MDBContainer, MDBRow, MDBCol } from "mdb-react-ui-kit";
import { Button } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import InputTextComponent from "../component/InputTextComponent";
import LableComponent from "../component/LableComponent";

function Login() {

  const navigate = useNavigate();



//validations for all InputtextComponent 
  const[error,setError]=useState(false);

  let regmail = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w\w+)+$/;

  const validate = () => {
    if (input.value.length === 0) {
      setError(true);
      }
     else if (regmail.test(input) === false) {
      // setRegemail(true);
      setError(true);
    }
    
     else {
      navigate("/home");
    }
  };

  
//require State for all InputTextComponent
const [input,setInput]=useState({});

const submitData=(e)=>{
   const name = e.target.name;
  const value= e.target.value;
  setInput((data)=>({...data, [name]: value}))
  console.log(input);
}



  const [passwordIcon, setPasswordIcon] = useState(<FaEyeSlash />);
  const [passwordType, setPasswordType] = useState("password");
  
//Password Hide & show Toggle Function  
  const handelToggle = () => {
    if (passwordType === "password") {
      setPasswordType("text");
      setPasswordIcon(FaRegEye);
    } else {
      setPasswordType("password");
      setPasswordIcon(FaEyeSlash);
    }
  };




  return (
    <MDBContainer className="my-3 gradient-form">
      <MDBRow>
        <MDBCol col="4" className="mb-5">
          <div className="d-flex flex-column ms-5">
            <div className="text-center">
              <img
                src="assets/logo/reg.jpg"
                style={{ width: "138px" }}
                alt="logo"
              />
              <h5 id="title">LOGIN PAGE</h5>
            </div>
            <br />
            <p id="para">Please login to your account</p>
            
            <InputTextComponent
             type="email"
              placeholder="Email address"
              name="email"
              value={input.email ||""}
              onChange={submitData}
                // setRegemail(false);
            />
            {error && input.value.length <= 0 ? (
              <LableComponent text="Email can't be empty " />
             ) : (
              ""
            )}
            {/* {regemail || (error && email.length <= 0) ? (
              <LableComponent text="Please Enter valid email " />
            ) : (
              ""
            )} */}

            <InputTextComponent
              placeholder="Password"
              name="password"
              value={input.password || ""}
              onChange={submitData}

              type={passwordType}
            />
            <span id="eye" onClick={handelToggle}>
              {passwordIcon}
            </span>
            <br />
            {error && input.length <= 0 ? (
              <LableComponent text="Password can't be empty" />
            ) : (
              ""
            )}
            <p id="forgetP" style={{ color: "#111011" }}>
              <Link to="/forget">Forget Password</Link>{" "}
            </p>
            <p id="login-to">
              {" "}
              <Link to="/">Don't have an account?</Link>
            </p>

            <Button id="signin" onClick={validate} >
              Sign in
            </Button>
            <br />
          </div>
        </MDBCol>
      </MDBRow>
    </MDBContainer>
  );
}

export default Login;
